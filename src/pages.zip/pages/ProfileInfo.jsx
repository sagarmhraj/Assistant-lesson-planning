import React from 'react';
import PropTypes from 'prop-types';
import '../styles/profilecard.css';

const ProfileCard = ({ profilePicture, name, address, email, contactNumber, designation }) => {
  // Check if any required user details are not available
  const isUserDataIncomplete = !profilePicture || !name || !address || !email || !contactNumber || !designation;

  return (
    <div className="profile-card">
      {isUserDataIncomplete ? (
        <p>Loading...</p>
      ) : (
        <>
          <img src={profilePicture} alt="Profile" className="profile-picture" />
          <h2>{name}</h2>
          <div className="profile-details">
            <p><strong>Address:</strong> {address}</p>
            <p><strong>Email:</strong> {email}</p>
            <p><strong>Contact Number:</strong> {contactNumber}</p>
            <p><strong>Designation:</strong> {designation}</p>
          </div>
        </>
      )}
    </div>
  );
};

ProfileCard.propTypes = {
  profilePicture: PropTypes.string,
  name: PropTypes.string,
  address: PropTypes.string,
  email: PropTypes.string,
  contactNumber: PropTypes.string,
  designation: PropTypes.string,
};

export default ProfileCard;
