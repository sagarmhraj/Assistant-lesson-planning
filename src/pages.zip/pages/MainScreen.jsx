import React, { useEffect, useState } from 'react';
import { getFirestore, collection, getDocs } from 'firebase/firestore';
import PostContainer from './PostContainer';

const MainScreen = () => {
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchPosts = async () => {
      const db = getFirestore();
      const postsCollection = collection(db, 'posts');
      const postsSnapshot = await getDocs(postsCollection);
      const postsData = [];

      postsSnapshot.forEach((doc) => {
        const postData = doc.data();
        postsData.push(postData);
      });

      setPosts(postsData);
      setLoading(false);
    };

    fetchPosts();
  }, []);

  return (
    <div>
      {loading ? (
        <p>Loading...</p>
      ) : (
        posts.map((post, index) => (
          <PostContainer key={index} post={post} />
        ))
      )}
    </div>
  );
};

export default MainScreen;
